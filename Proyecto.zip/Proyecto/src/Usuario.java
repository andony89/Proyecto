
import javax.swing.JOptionPane;

public class Usuario {

    public void Usuario() {

        Cliente cliente1 = new Cliente();

        for (int i = 1; i < 6; i++) {
            System.out.println("Inicia For");
            JOptionPane.showMessageDialog(null, "Bienvenid@ usted es el cliente " + i);

            cliente1.setNombre(JOptionPane.showInputDialog(null, "Digite su nombre"));
            cliente1.setCorreo(JOptionPane.showInputDialog(null, "Digite su correo electronico"));
            cliente1.setTelefono(JOptionPane.showInputDialog(null, "Digite su numero telefonico"));

            JOptionPane.showMessageDialog(null, "Informacion: \n" + cliente1.getNombre() + "\n" + cliente1.getCorreo() + "\n" + cliente1.getTelefono());

            statica.matriz[i - 1][0] = cliente1.getNombre();
            

            statica.matriz[i - 1][1] = cliente1.getCorreo();
           

            statica.matriz[i - 1][2] = cliente1.getTelefono();
           
            Tratamientos t = new Tratamientos();
            t.Tratamientos();

            Horarios h = new Horarios();
            h.Horarios();

            System.out.println(i);
            System.out.println("Termina For");

        }
        

        System.out.println("entrando en admin");
    }

}
