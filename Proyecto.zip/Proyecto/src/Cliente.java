
public class Cliente {

    private String Nombre;
    private String Telefono;
    private String Correo;

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String aNombre) {
        Nombre = aNombre;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String aTelefono) {
        Telefono = aTelefono;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String aCorreo) {
        Correo = aCorreo;
    }

}
