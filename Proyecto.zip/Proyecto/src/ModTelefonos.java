
import javax.swing.JOptionPane;

public class ModTelefonos {

    Usuario m = new Usuario();

    public void ModTelefonos() {
        int n;
        n = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite el numero de cliente que desea modificar"));

        statica.matriz[n-1][2] = JOptionPane.showInputDialog(null, "Escriba el nuevo Telefono");
        System.out.println(statica.matriz[n][2]);

    }

}
