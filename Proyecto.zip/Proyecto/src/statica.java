
public class statica {
    public static String matriz[][] = new String[5][3];
}
