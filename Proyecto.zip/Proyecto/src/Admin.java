
import javax.swing.JOptionPane;

public class Admin {

    ModNombres n = new ModNombres();
    ModCorreos c = new ModCorreos();
    ModTelefonos t = new ModTelefonos();
    L_Clientes l = new L_Clientes();
    int op = 0;

    public void Admin() {
        while (op != 5) {
            op = Integer.parseInt(JOptionPane.showInputDialog(null, "---Bienvenido Admin---\nDIigite el numero de lo que desea hacer: \n1.Modificar Nombre del cliente \n2.Modificar Correo del Cliente \n3.Modificar el telefono de un cliente \n4.Ver lista de clientes \n5.Salir"));
            if (op == 1) {
                n.ModNombres();
            } else if (op == 2) {
                c.ModCorreos();
            } else if (op == 3) {
                t.ModTelefonos();
            } else if (op == 4) {
                l.L_Clientes();

            }
        }
    }
}
