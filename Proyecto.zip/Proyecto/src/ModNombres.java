
import javax.swing.JOptionPane;

public class ModNombres {

    Usuario m = new Usuario();

    public void ModNombres() {
        int n;
        n = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite el numero de cliente que desea modificar"));

        statica.matriz[n - 1][0] = JOptionPane.showInputDialog(null, "Escriba el nuevo nombre");
        System.out.println(statica.matriz[n][0]);

    }

}
