
import javax.swing.JOptionPane;

public class L_Clientes {

    public void L_Clientes() {

        JOptionPane.showMessageDialog(null, "La matriz contiene:"
                + "\n" + statica.matriz[0][0] + " " + statica.matriz[0][1] + " " + statica.matriz[0][2]
                + "\n" + statica.matriz[1][0] + " " + statica.matriz[1][1] + " " + statica.matriz[1][2]
                + "\n" + statica.matriz[2][0] + " " + statica.matriz[2][1] + " " + statica.matriz[2][2]
                + "\n" + statica.matriz[3][0] + " " + statica.matriz[3][1] + " " + statica.matriz[3][2]
                + "\n" + statica.matriz[4][0] + " " + statica.matriz[4][1] + " " + statica.matriz[4][2]);
    }

}
