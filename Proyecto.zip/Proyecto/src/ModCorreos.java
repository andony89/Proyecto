
import javax.swing.JOptionPane;

public class ModCorreos {

    Usuario m = new Usuario();

    public void ModCorreos() {
        int n;
        n = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite el numero de cliente que desea modificar"));

        statica.matriz[n-1][1] = JOptionPane.showInputDialog(null, "Escriba el nuevo Correo");
        System.out.println(statica.matriz[n][1]);

    }

}
