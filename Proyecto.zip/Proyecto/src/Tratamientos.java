
import javax.swing.JOptionPane;

public class Tratamientos {

    public static void Tratamientos() {

        int tratamiento = 0;
        int k = 0;
        int precio_final = 0;
        int repetir;
        int temp = 0;
        repetir = 's';

        while (repetir == 's') {
            //precio_final=precio_final+temp;
            k = k + 1;
            int costo = 0;
            int Confirmacion;
            tratamiento = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el numero del tratamiento que desea realizar \n1. Blanqueamiento \n2.Revision Dental \n3.Limpieza completa"));

            if (tratamiento == 1) {
                costo = 500;
                temp = costo;
                precio_final = costo;
                JOptionPane.showMessageDialog(null, "El costo por el blanqueamiento es de " + costo);

            } else if (tratamiento == 2) {
                costo = 120;
                temp = costo;
                precio_final = costo;
                JOptionPane.showMessageDialog(null, "El costo por la Revision Dental es de " + costo);
            } else if (tratamiento == 3) {
                costo = 150;
                temp = costo;
                precio_final = costo;
                JOptionPane.showMessageDialog(null, "El costo por la Limpieza Completa es de " + costo);
            }
            if (k > 1) {
                precio_final = precio_final + temp;
            }

            JOptionPane.showMessageDialog(null, "El precio final que debe pagar es de: " + precio_final);
            repetir = JOptionPane.showInputDialog(null, "Desea añadir otro tratamiento (s/n)?").charAt(0);

        }

    }
}
