
import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) {

        int k;
        
        Usuario u = new Usuario();
        u.Usuario();

        k = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite la contraseña (la contraseña es 123)"));
        if (k == 123) {
            Admin a = new Admin();
            a.Admin();
        } else {
            JOptionPane.showMessageDialog(null, "Gracias");
        }

    }
}
