
import javax.swing.JOptionPane;

public class Horarios {

    public static void Horarios() {
        System.out.println("Horarios");
        int Dia;
        int Hora;
        int c = 0;
        c = 'n';

        while (c == 'n') {
            Dia = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite el dia en el que quiere agendar su cita \n1.Lunes\n2.Martes\n3.Miercoles\n4.Jueves\n5.Viernes"));
            if (Dia <= 1) {
                Hora = Integer.parseInt(JOptionPane.showInputDialog(null, "Elija su horario de 1pm a 5pm \n(solo digite el numero de la hora)"));
                c = JOptionPane.showInputDialog(null, "Su cita sera el dia Lunes a las " + Hora + "pm \nSi No").charAt(0);

            } else if (Dia <= 2) {
                Hora = Integer.parseInt(JOptionPane.showInputDialog(null, "Elija su horario de 1pm a 5pm \n(solo digite el numero de la hora)"));
                c = JOptionPane.showInputDialog(null, "Su cita sera el dia Martes a las " + Hora + "pm \nSi No").charAt(0);

            } else if (Dia <= 3) {
                Hora = Integer.parseInt(JOptionPane.showInputDialog(null, "Elija su horario de 1pm a 5pm \n(solo digite el numero de la hora)"));
                c = JOptionPane.showInputDialog(null, "Su cita sera el dia Miercoles a las " + Hora + "pm \nSi No").charAt(0);
            } else if (Dia <= 4) {
                Hora = Integer.parseInt(JOptionPane.showInputDialog(null, "Elija su horario de 1pm a 5pm \n(solo digite el numero de la hora)"));
                c = JOptionPane.showInputDialog(null, "Su cita sera el dia Jueves a las " + Hora + "pm \nSi No").charAt(0);
            } else if (Dia <= 5) {
                Hora = Integer.parseInt(JOptionPane.showInputDialog(null, "Elija su horario de 1pm a 5pm \n(solo digite el numero de la hora)"));
                c = JOptionPane.showInputDialog(null, "Su cita sera el dia Viernes a las " + Hora + "pm \nSi No").charAt(0);
            }
        }
    }
}
